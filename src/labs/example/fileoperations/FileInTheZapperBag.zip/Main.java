//Ethan Bradshaw
//March 26th
//Week 11 lab Main
package labs.example.fileoperations;

public class Main{
    public static void main(String[] args){
        FileOperations fileOperations = new FileOperations();

        //call the open() file method
        fileOperations.OpenFile();


    }
}